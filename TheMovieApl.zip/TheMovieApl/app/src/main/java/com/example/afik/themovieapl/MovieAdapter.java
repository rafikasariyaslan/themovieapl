package com.example.afik.themovieapl;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MovieAdapter extends BaseAdapter {
    private ArrayList<MovieItems> mData = new ArrayList<>();
    private LayoutInflater mInflater;
    private Context context;

    public MovieAdapter(Context context) {
        this.context = context;
        mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    public void setData(ArrayList<MovieItems> items){
        mData = items;
        notifyDataSetChanged();
    }
    public void addItem(final MovieItems item) {
        mData.add(item);
        notifyDataSetChanged();
    }
    public void clearData(){
        mData.clear();
    }
    @Override
    public int getItemViewType(int position) {
        return 0;
    }
    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public int getCount() {
        if (mData == null) return 0;
        return mData.size();
    }

    @Override
    public MovieItems getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.movie_items, null);
            holder.textViewJudulMovie= (TextView)convertView.findViewById(R.id.textName);
            holder.textViewTime = (TextView)convertView.findViewById(R.id.textTime);
            holder.textViewGenre = (TextView)convertView.findViewById(R.id.genre);
            holder.textViewRating = (TextView)convertView.findViewById(R.id.rating);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.textViewJudulMovie.setText(mData.get(position).getName());
        holder.textViewTime.setText(mData.get(position).getTime());
        holder.textViewGenre.setText(mData.get(position).getGenre());
        holder.textViewRating.setText(mData.get(position).getRating());
        return convertView;
    }
    private static class ViewHolder {
        public TextView textViewJudulMovie;

        public TextView textViewTime;
        public TextView textViewGenre;
        public TextView textViewRating;
    }
}
