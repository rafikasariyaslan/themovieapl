package com.example.afik.themovieapl;

import org.json.JSONObject;

import java.text.DecimalFormat;

public class MovieItems {
    private int id;
    private String judul;
    private String rilis;
    private String genre;
    private String rating;

    public MovieItems (JSONObject object) {
        try {
            int id = object.getInt("id");
            String judul = object.getString("title");
            String rilis = object.getJSONArray("realese").getJSONObject(0).getString("main");
            String genre = object.getJSONArray("genre").getJSONObject(0).getString("genre");
            double ratingFilm = object.getJSONObject("main").getDouble("rating");
            String rating = new DecimalFormat("#.#").format(ratingFilm);
            this.id = id;
            this.judul = judul;
            this.rilis = rilis;
            this.genre = genre;
            this.rating = rating;
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
